# gemini_runner.py - V5 (ASCII Uyumlu ve Hafızalı)

import os
import sys
import json
from google import genai
from google.genai.errors import APIError
from google.genai.types import Content, Part

# Konuşma geçmişi dosyasının adı (ŞİMDİ SADECE ASCII KARAKTERLER KULLANIYORUZ)
GECMIS_DOSYASI = "konusma_gecmisi.json" 

# **ÖNEMLİ:** API Anahtarınız
API_KEY = "AIzaSyCAPOKOjzwMQrvBr-A7NUIsO1W2u3_8SHg" 
os.environ['GEMINI_API_KEY'] = API_KEY


def yukle_gecmis():
    """Dosyadan ham JSON geçmişini yükler."""
    if os.path.exists(GECMIS_DOSYASI):
        try:
            with open(GECMIS_DOSYASI, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            # Yükleme hatası olursa, konsola yazdır ve boş liste döndür
            print(f"HATA: Geçmiş yüklenirken JSON hatası: {e}", file=sys.stderr)
            return []
    return []


def kaydet_gecmis(gecmis_listesi):
    """Güncel geçmiş listesini dosyaya kaydeder."""
    try:
        with open(GECMIS_DOSYASI, 'w', encoding='utf-8') as f:
            # ensure_ascii=False, Türkçe karakterlerin bozulmasını engeller.
            json.dump(gecmis_listesi, f, ensure_ascii=False, indent=2) 
    except Exception as e:
        print(f"HATA: Geçmiş kaydedilirken sorun oluştu: {e}", file=sys.stderr)


# --- Ana Çalışma Bloğu ---

if __name__ == "__main__":
    
    # Prompt'u C++'tan komut satırı argümanı olarak al
    if len(sys.argv) < 2:
        # Prompt yoksa, geçmişi temizle ve çık (C++'taki hafizasil komutu burayı çağırır)
        if os.path.exists(GECMIS_DOSYASI):
            os.remove(GECMIS_DOSYASI)
            print("OTURUM_TEMİZLENDİ", file=sys.stdout) # C++'ın okuması için stdout
        sys.exit(0)

    prompt = " ".join(sys.argv[1:])

    try:
        client = genai.Client()
        
        # Geçmişi yükle (Ham JSON formatında)
        gecmis = yukle_gecmis()

        # Geçmişe yeni kullanıcı mesajını ekle
        gecmis.append({
            "role": "user",
            "parts": [{"text": prompt}]
        })

        # API isteği yap (history ve prompt'u birleştirerek gönderiyoruz)
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=gecmis
        )
        
        cevap = response.text
        
        # Cevabı geçmişe ekle
        gecmis.append({
            "role": "model",
            "parts": [{"text": cevap}]
        })
        
        # Güncel geçmişi kaydet
        kaydet_gecmis(gecmis) 
        
        # Cevabı konsola yazdır
        print(cevap)

    except APIError as e:
        print(f"HATA: Gemini API istegi sirasinda sorun olustu: {e}", file=sys.stderr)
    except Exception as e:
        print(f"HATA: Beklenmedik bir sorun olustu: {e}", file=sys.stderr)
